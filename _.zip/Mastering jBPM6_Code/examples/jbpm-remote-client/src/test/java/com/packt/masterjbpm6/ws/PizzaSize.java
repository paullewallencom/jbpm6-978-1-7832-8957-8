package com.packt.masterjbpm6.ws;

enum PizzaSize {
	MEDIUM, LARGE, XLARGE
}
