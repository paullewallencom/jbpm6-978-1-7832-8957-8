package com.packt.masterjbpm6.ws;

import java.util.HashMap;
import java.util.Map;

public class PriceList {

	
	private Map<String, Double> costs = new HashMap<String, Double>();

}
