package com.packt.masterjbpm6.ws;

public enum Types {
	MARGHERITA, NAPOLI, SALAME, FOURSEASONS
}
