package com.packt.masterjbpm6.kie;


public class Kie extends KieTest {
	//
	public Kie() {
	}



}
