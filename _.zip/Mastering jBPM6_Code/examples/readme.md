Packt - Mastering jBPM 6 examples (by Chapter)
=======================


chapter 4:
-pizza
-pizzadelivery
-pizzamodel


chapter 5:
jbpm-constructs


chapter 6:

chapter 7:
-jbpm-marshalling
-pizzahandlers
-pizzatweet

chapter 8:
-jbpm-remote-client
-jbpm-remote-server

