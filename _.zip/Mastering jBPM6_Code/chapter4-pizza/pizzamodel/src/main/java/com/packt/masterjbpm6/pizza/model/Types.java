package com.packt.masterjbpm6.pizza.model;

public enum Types {
	MARGHERITA, NAPOLI, SALAME, FOURSEASONS
}
