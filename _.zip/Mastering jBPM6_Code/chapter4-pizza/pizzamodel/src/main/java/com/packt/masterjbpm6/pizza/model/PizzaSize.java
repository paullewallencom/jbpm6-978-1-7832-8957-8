package com.packt.masterjbpm6.pizza.model;

enum PizzaSize {
	MEDIUM, LARGE, XLARGE
}
