# chapter4-managed
Kie managed repository projects
